import os
import time
import json
import glob
import platform
import subprocess
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from scipy.interpolate import griddata
import sys

FLOORPLAN_IMAGE_PATH = ''
OUTPUT_DATA_PATH = 'wifi_points.json'
SAMPLE_DURATION = 5
SAMPLE_INTERVAL = 0.25
HEATMAP_ALPHA = 0.5

def find_floorplan_image():
    if FLOORPLAN_IMAGE_PATH and os.path.exists(FLOORPLAN_IMAGE_PATH):
        return FLOORPLAN_IMAGE_PATH
    for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
        matches = glob.glob(ext)
        if matches:
            print(f"[INFO] Using floorplan: {matches[0]}")
            return matches[0]
    raise FileNotFoundError("DISKREADFAIL Floorplan image not found.")

 
def get_signal_strength():
    system = platform.system()

    def parse(raw):
        if 'Signal' in raw:
            for line in raw.splitlines():
                if 'Signal' in line:
                    val = line.split(':')[1].strip().replace('%', '')
                    try:
                        return int(val)
                    except Exception:
                        continue
        elif 'Signal level=' in raw:
            for line in raw.splitlines():
                if 'Signal level=' in line:
                    try:
                        return int(line.split('Signal level=')[1].split()[0])
                    except Exception:
                        continue
        elif 'IN-USE' in raw:
            for line in raw.splitlines():
                if '*' in line:
                    try:
                        return int(line.split()[-1]) - 100
                    except Exception:
                        continue
        return None

    try:
        if system == 'Windows':
            output = subprocess.check_output(['netsh', 'wlan', 'show', 'interfaces'], text=True)
        elif system == 'Linux':
            try:
                output = subprocess.check_output(["nmcli", "-f", "IN-USE,SSID,SIGNAL", "dev", "wifi"], text=True)
            except Exception:
                try:
                    output = subprocess.check_output(["iwconfig"], text=True)
                except Exception:
                    return None
        else:
            return None
        return parse(output)
    except Exception as e:
        print(f"[!] Signal error: {e}")
        return None

def average_signal(duration=SAMPLE_DURATION, interval=SAMPLE_INTERVAL):
    readings = []
    start = time.time()
    while time.time() - start < duration:
        val = get_signal_strength()
        if val is not None:
            readings.append(val)
        time.sleep(interval)
    if readings:
        return int(round(sum(readings) / len(readings)))
    return None

def update_plot(ax, img, points, route_x, route_y, highlight_index=None):
    ax.clear()
    ax.imshow(img)

     
    if len(points) >= 3:
        x_coords = np.array([p['x'] for p in points])
        y_coords = np.array([p['y'] for p in points])
        signals = np.array([p['signal'] for p in points])

        grid_x, grid_y = np.meshgrid(
            np.linspace(0, img.shape[1], img.shape[1]),
            np.linspace(0, img.shape[0], img.shape[0])
        )

        try:
            grid_z = griddata(
                (x_coords, y_coords),
                signals,
                (grid_x, grid_y),
                method='linear'
            )
        except Exception:
            grid_z = griddata(
                (x_coords, y_coords),
                signals,
                (grid_x, grid_y),
                method='nearest'
            )
        ax.imshow(grid_z, extent=(0, img.shape[1], img.shape[0], 0),
                  cmap='jet', alpha=HEATMAP_ALPHA)
    # Fix: Only plot route if route_x and route_y are not empty
    if route_x and route_y:
        ax.plot(route_x, route_y, 'r--', marker='o', markersize=6, label='Route')
    # Fix: Only highlight if highlight_index is valid
    if highlight_index is not None and 0 <= highlight_index < len(route_x):
        ax.plot(route_x[highlight_index], route_y[highlight_index], 'go', markersize=10, label='Current Target')
    ax.set_title("Live WiFi Signal Mapping")
    ax.axis('off')
    # Fix: Only show legend if there are labeled items
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        ax.legend(loc='upper right')
    ax.figure.canvas.draw()
    plt.pause(0.001)

# Robust image loading
try:
    floorplan_path = find_floorplan_image()
    img = mpimg.imread(floorplan_path)
except Exception as e:
    print(f"DISKREADFAIL Could not load floorplan image: {e}")
    sys.exit(1)

wifi_points = []
if os.path.exists(OUTPUT_DATA_PATH):
    try:
        with open(OUTPUT_DATA_PATH, 'r') as f:
            existing_data = json.load(f)
            if isinstance(existing_data, list):
                wifi_points.extend(existing_data)
                print(f"DISKREADSUCCESS Loaded {len(existing_data)} previously collected points.")
    except Exception as e:
        print(f"DISKREADFAIL Failed to read existing data: {e}")

plt.ion()
fig, ax = plt.subplots()
ax.imshow(img)
ax.set_title("Click your custom walking route. Press ENTER when done.")
plt.show(block=False)
plt.pause(0.1)
# Add timeout to ginput to avoid hanging forever
try:
    route = plt.ginput(n=-1, timeout=60)
except Exception as e:
    print(f"PATHERROR Route selection failed: {e}")
    plt.close('all')
    sys.exit(1)
plt.close(fig)

if not route:
    print("PATHERROR No route selected.")
    plt.close('all')
    sys.exit(1)

route_x = [int(x) for x, y in route]
route_y = [int(y) for x, y in route]

fig2, ax2 = plt.subplots()
fig2.canvas.manager.set_window_title("WiFi Mapping Live View")

plt.ion()
plt.show(block=False)

fig2.canvas.draw()
plt.pause(0.5)
update_plot(ax2, img, wifi_points, route_x, route_y, highlight_index=0)

print("\nSTARTROUTE Start walking. Ctrl+C exits early and saves data.\n")

try:
    for i, (x, y) in enumerate(zip(route_x, route_y)):
        print(f"[{i+1}/{len(route)}] Move to point ({x}, {y})")
        update_plot(ax2, img, wifi_points, route_x, route_y, highlight_index=i)
        for t in range(5, 0, -1):
            print(f"  Waiting {t}s...", end='\r')
            time.sleep(1)
        strength = average_signal()
        if strength is not None:
            wifi_points.append({"x": x, "y": y, "signal": strength})
            print(f"SIGNALSUCCESS {strength:.1f} dBm at ({x}, {y})\n")
        else:
            print("SIGNALREADFAIL Signal read failed.\n")
        update_plot(ax2, img, wifi_points, route_x, route_y, highlight_index=i+1)
except KeyboardInterrupt:
    print("\nERROR Interrupted. Saving data...\n", file=sys.stderr)

# Only save if there are points
if wifi_points:
    try:
        with open(OUTPUT_DATA_PATH, 'w') as f:
            json.dump(wifi_points, f, indent=2)
        print(f"DISK_OP_SUCCESS Data saved to {OUTPUT_DATA_PATH} ({len(wifi_points)} total points)")
    except Exception as e:
        print(f"DISKWRITEFAIL Failed to save data: {e}")
else:
    print("DISKWRITEFAIL No data to save.")

plt.ioff()
plt.close('all')
plt.show()
