import json
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import glob
from scipy.interpolate import griddata


FLOORPLAN_IMAGE_PATH = ''  # No default; prompt user if not found
DATA_FILE = 'wifi_points.json'
HEATMAP_ALPHA = 0.5


def find_floorplan_image():
    # Try environment variable first (for container use)
    env_path = os.environ.get('FLOORPLAN_IMAGE_PATH')
    if env_path and os.path.exists(env_path):
        print(f"[INFO] Using floorplan from environment: {env_path}")
        return env_path
    if FLOORPLAN_IMAGE_PATH and os.path.exists(FLOORPLAN_IMAGE_PATH):
        return FLOORPLAN_IMAGE_PATH
    for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
        matches = glob.glob(ext)
        if matches:
            print(f"[INFO] Using floorplan image: {matches[0]}")
            return matches[0]
    # Prompt user for path
    while True:
        user_path = input("Enter path to floorplan image (jpg/png/bmp): ").strip()
        if os.path.exists(user_path):
            print(f"[INFO] Using user-provided floorplan: {user_path}")
            return user_path
        print("File not found. Please try again.")


try:
    floorplan_path = find_floorplan_image()
    img = mpimg.imread(floorplan_path)
    img_height, img_width = img.shape[0], img.shape[1]
except Exception as e:
    print(f"**NONFATALERROR** Could not load floorplan image: {e}")
    exit(1)

if not os.path.exists(DATA_FILE):
    print(f"**NONFATALERROR** Cannot find {DATA_FILE}. Run the mapping tool first.")
    exit(1)

try:
    with open(DATA_FILE, 'r') as f:
        wifi_points = json.load(f)
except Exception as e:
    print(f"**NONFATALERROR** Failed to read {DATA_FILE}: {e}")
    exit(1)

if not isinstance(wifi_points, list) or len(wifi_points) < 3:
    print("**NONFATALERROR** Need at least 3 WiFi data points for interpolation.")
    exit(1)


x_coords = np.array([pt['x'] for pt in wifi_points])
y_coords = np.array([pt['y'] for pt in wifi_points])
signals = np.array([pt['signal'] for pt in wifi_points])


grid_x, grid_y = np.meshgrid(
    np.linspace(0, img_width, img_width),
    np.linspace(0, img_height, img_height)
)

# Try cubic, fallback to linear, then nearest
try:
    grid_z = griddata(
        points=(x_coords, y_coords),
        values=signals,
        xi=(grid_x, grid_y),
        method='cubic'
    )
except Exception:
    try:
        grid_z = griddata(
            points=(x_coords, y_coords),
            values=signals,
            xi=(grid_x, grid_y),
            method='linear'
        )
    except Exception:
        grid_z = griddata(
            points=(x_coords, y_coords),
            values=signals,
            xi=(grid_x, grid_y),
            method='nearest'
        )


plt.figure(figsize=(10, 8))
plt.imshow(img, extent=(0, img_width, img_height, 0))
if grid_z is not None:
    plt.imshow(grid_z, extent=(0, img_width, img_height, 0),
               cmap='jet', alpha=HEATMAP_ALPHA)
    plt.colorbar(label='WiFi Signal Strength (dBm)')
else:
    print("**NONFATALERROR** Could not generate heatmap.")

plt.title("WiFi Signal Strength Heatmap")
plt.axis('off')
plt.tight_layout()
plt.show()
plt.close('all')
