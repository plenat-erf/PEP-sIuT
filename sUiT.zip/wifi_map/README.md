c# **𝓗\~€\~𝕽\~ᑭ\~𝓔\~$**
## *(**H**is **E**ccentric **R**untime **P**rovisional **E**numerating **S**ystem)*
     A basic and janky household wifi signal mapping utility for windows. This was written just to learn a few things, but works good enough to publish.

    
## Manual Installation

Check for python3 install:

```bash
 python -V
```

If no python install is found, follow the download and install instructions on the [Python website](https://www.python.org/downloads/) or with CMD using the below commands:

```bash
 winget source reset
  winget install --id Python.Python.3 --source winget
```

Install dependencies

```bash
  pip install -r requirements.txt
```

This is all thesetup you need in the terminal, though you ***MUST ENSURE THERE IS AN IMAGE FILE OF THE FLOORPLAN IN THIS CUURENT FOLDER(wifi_map )***. This can be named anything, but must be the only image file in the folder.

Once the floorplan image is in place, start the mapping tool with

```bash
  python wifi_map.py
```


## Contributing

Contributions are always welcome!

Please email the [maintainer](mailto:joshuasturre1@gmail.com) to get involved!


## Acknowledgements

 - Shout out to StackOverflow and Reddit, always got the answers.


## Contact OWNER AUTHOR AND MAINTAINER

- Joshua Sturre -- [joshuasturre1@gmail.com](mailto:joshuasturre1@gmail.com)

